webpackJsonp([153],{788:function(e,d,t){"use strict";function r(e,d,t,r){return o[e]}Object.defineProperty(d,"__esModule",{value:!0}),d.default=r;var o={lastWeek:"[hier] dddd [à] LT",yesterday:"[hier à] LT",today:"[aujourd’hui à] LT",tomorrow:"[demain à] LT",nextWeek:"dddd [à] LT",other:"L"};e.exports=d.default}});
//# sourceMappingURL=1ad4450d388f1d9d6f24.js.map

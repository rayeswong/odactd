webpackJsonp([173],{762:function(e,t,d){"use strict";function a(e,t,d,a){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=a;var o={lastWeek:"[pasinta] dddd [je] LT",yesterday:"[hieraŭ je] LT",today:"[hodiaŭ je] LT",tomorrow:"[morgaŭ je] LT",nextWeek:"dddd [je] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=95e80ce73b6af9061acc.js.map

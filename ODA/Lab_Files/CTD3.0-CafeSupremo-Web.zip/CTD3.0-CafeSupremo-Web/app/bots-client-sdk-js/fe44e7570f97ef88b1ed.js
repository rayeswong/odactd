webpackJsonp([154],{787:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var t=Y(194),L=function(e){return e&&e.__esModule?e:{default:e}}(t),d=(0,L.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD.MM.YYYY",LL:"D MMMM YYYY",LLL:"D MMMM YYYY HH:mm",LLLL:"dddd, D MMMM YYYY HH:mm"});M.default=d,e.exports=M.default}});
//# sourceMappingURL=fe44e7570f97ef88b1ed.js.map
